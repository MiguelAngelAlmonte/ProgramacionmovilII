//
//  ViewController.swift
//  Nivelacionp
//
//  Created by Mac1 on 08/07/21.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    
    
    @IBOutlet weak var Talumnos: UITableView!
    var nivelacion = [Datosnivelacion]()
    let contexto = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var nombresend: String?
    var numerosend: Int64?
    var calificacionsend: Double?
    var indice: Int?
    

    override func viewDidLoad() {
        super.viewDidLoad()
        cargarCoreData()
        Talumnos.reloadData()
        Talumnos.delegate = self
        Talumnos.dataSource = self
        Talumnos.register(UINib(nibName: "NivelacionTableViewCell", bundle: nil),forCellReuseIdentifier : "celda")
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        Talumnos.reloadData()
    }
    
    @IBAction func newAlumno(_ sender: UIBarButtonItem) {
        let alerta = UIAlertController(title: "Agregar", message: "Nuevo Alumno", preferredStyle: .alert)
        let acctionAcept = UIAlertAction(title: "Agregar", style: .default) { (_) in
            print("Se agrego el alumno correctamente")
            //obj paa guardar en Coredata
            
            
            
            guard let nombreAlert = alerta.textFields?.first?.text else {return}
            guard let numeroAlert = Int64(alerta.textFields?[1].text ?? "00000000") else {return}
            guard let califAlert = Double(alerta.textFields?.last?.text ?? "00") else {return}
            let imageTemporal = UIImageView(image: #imageLiteral(resourceName: "emoji"))
            //let newContact = MiContacto(nombre: nombreAlert, telefono: telefonoAlert, correo: correoAlert)
            let newContact = Datosnivelacion(context: self.contexto)
            newContact.nombre = nombreAlert
            newContact.numero = numeroAlert
            newContact.calificacion = califAlert
            newContact.imagen = imageTemporal.image!.pngData()
            
            self.nivelacion.append(newContact)
            self.guardarContact()
            self.Talumnos.reloadData()
        }
        alerta.addTextField { (nombreTxt) in
            nombreTxt.placeholder = "Nombre"
            nombreTxt.textColor = .blue
            nombreTxt.textAlignment = .center
            nombreTxt.autocapitalizationType = .words
        }
        alerta.addTextField { (numeroTxt) in
            numeroTxt.placeholder = "Numero C."
            numeroTxt.keyboardType = .numberPad
            numeroTxt.textColor = .blue
            numeroTxt.textAlignment = .center
        }
        alerta.addTextField { (caliTxt) in
            caliTxt.placeholder = "Calificaciòn"
            caliTxt.textColor = .blue
            caliTxt.textAlignment = .center
        }
        
        alerta.addAction(acctionAcept)
        let actionCancel = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        alerta.addAction(actionCancel)
        present(alerta, animated: true)
        
        
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nivelacion.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celd = Talumnos.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! NivelacionTableViewCell
        celd.NombreLabel.text = nivelacion[indexPath.row].nombre
        celd.NumeroLabel.text = "🔵 \(nivelacion[indexPath.row].numero )"
        celd.CalificacionLabel.text = "⚰️\(nivelacion[indexPath.row].calificacion)"
        celd.ImagenPerfil.image = UIImage(data: nivelacion[indexPath.row].imagen!)
        return celd
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 135
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Talumnos.deselectRow(at: indexPath, animated: true)
        nombresend = nivelacion[indexPath.row].nombre
        numerosend = nivelacion[indexPath.row].numero
        calificacionsend = nivelacion[indexPath.row].calificacion
        indice = indexPath.row
        print("indice \(indexPath.row)")
        performSegue(withIdentifier: "pasardatos", sender: self)
    }
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let accionDelete = UIContextualAction(style: .normal, title: "") { (_,_,_) in
            
            print("Borrer")
            //eliminar
            self.contexto.delete(self.nivelacion[indexPath.row])  //coredata
            self.nivelacion.remove(at: indexPath.row)
            self.guardarContact()
            self.Talumnos.reloadData()
        }
        accionDelete.image = UIImage(named: "borrar.png")
        accionDelete.backgroundColor = .red
        
        return UISwipeActionsConfiguration(actions: [accionDelete])
    }
    func guardarContact() {
        do {
            try contexto.save()
            print("Se guardo correctamente")
        } catch let error as NSError {
            print("Error al guardar: \(error.localizedDescription)")
        }
    }
    
    func cargarCoreData() {
        
        let fetchRequest : NSFetchRequest< Datosnivelacion> = Datosnivelacion.fetchRequest()
        do {
            nivelacion = try contexto.fetch(fetchRequest)
        } catch  {
            print("Error al cargar DB")
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "pasardatos" {
            let objEdit = segue.destination as! EditalumnoViewController
            objEdit.recibeNombre = nombresend
            objEdit.recibeNumero = numerosend
            objEdit.recibeCalif = calificacionsend
            objEdit.recibeindice = indice
        }
    }
}

