//
//  NivelacionTableViewCell.swift
//  Nivelacionp
//
//  Created by Mac1 on 08/07/21.
//

import UIKit

class NivelacionTableViewCell: UITableViewCell {

    @IBOutlet weak var ImagenPerfil: UIImageView!
    @IBOutlet weak var NombreLabel: UILabel!
    @IBOutlet weak var NumeroLabel: UILabel!
    @IBOutlet weak var CalificacionLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
