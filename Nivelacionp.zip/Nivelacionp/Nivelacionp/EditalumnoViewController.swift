//
//  EditalumnoViewController.swift
//  Nivelacionp
//
//  Created by Mac1 on 08/07/21.
//
import CoreData
import UIKit

class EditalumnoViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate,UITextFieldDelegate {

    @IBOutlet weak var CalifTxtF: UITextField!
    @IBOutlet weak var nombreTextF: UITextField!
    @IBOutlet weak var ImagenAlumno: UIImageView!
    @IBOutlet weak var NumeroTxtF: UITextField!
    
    var recibeNombre: String?
    var recibeNumero: Int64?
    var recibeCalif: Double?
    var recibeindice: Int?
    var nivelacion = [Datosnivelacion]()
    let contexto = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cargarCoreData()
        print("indice: \(recibeindice!)")
        ImagenAlumno.image = UIImage(data: nivelacion[recibeindice!].imagen!)
        nombreTextF.text = recibeNombre
        
        NumeroTxtF.text = "\(recibeNumero ?? 0000)"
        print("telefono: \(recibeNumero ??  00)")
        CalifTxtF.text = recibeCalif?.description
        let gestura = UITapGestureRecognizer(target: self, action: #selector(clickImage))
        gestura.numberOfTapsRequired = 1
        gestura.numberOfTouchesRequired = 1
        ImagenAlumno.addGestureRecognizer(gestura)
        ImagenAlumno.isUserInteractionEnabled = true

       
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    @objc func clickImage(gestura: UITapGestureRecognizer){
        print("Cambia imagen")
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true, completion: nil)
    }
    func cargarCoreData() {
        
        let fetchRequest : NSFetchRequest< Datosnivelacion> = Datosnivelacion.fetchRequest()
        do {
            nivelacion = try contexto.fetch(fetchRequest)
        } catch  {
            print("Error al cargar DB")
        }
    }
    

   
    @IBAction func CancelarButton(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    @IBAction func GuardarButton(_ sender: UIButton) {
        do {
            nivelacion[recibeindice!].setValue(nombreTextF.text, forKey: "nombre")
            nivelacion[recibeindice!].setValue(Int64(NumeroTxtF.text ?? "0000"), forKey: "numero")
           // print("numero guardar : \(NumeroTxtF.text?.description ?? 0)")
            nivelacion[recibeindice!].setValue(Double(CalifTxtF.text ?? "00"), forKey: "calificacion")
            nivelacion[recibeindice!].setValue(ImagenAlumno.image?.pngData(), forKey: "imagen")
            try self.contexto.save()
            navigationController?.popViewController(animated: true)
            print("Se actualizo contexto")
        } catch  {
            print("erro al actualizar")
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let imageSelect = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage{
            ImagenAlumno.image = imageSelect
            
        }
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        nombreTextF.delegate = self
        return false
    }
    
    
    
}
