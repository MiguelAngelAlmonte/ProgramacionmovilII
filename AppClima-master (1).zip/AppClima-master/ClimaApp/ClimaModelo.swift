//
//  ClimaModelo.swift
//  ClimaApp
//
//  Created by Mac1 on 29/04/21.
//

import Foundation

struct ClimaModelo {
    let temp: Double
    let nombreCiudad: String
    let id: Int
    let sensacion: Double
    
    var sensacionString: String{
        return String(format: "%.1f", sensacion)
    }
    
    var tempString: String{
        return String(format: "%.1f", temp)
    }
    
    //propiedades calculadas
    var condicionClima: String {
        switch id {
        case 800:
            return "sun.max"
        default:
            return "cloud"
        }
    }
    
    
    
}
