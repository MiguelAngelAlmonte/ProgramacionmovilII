//
//  ClimaDatos.swift
//  ClimaApp
//
//  Created by Mac1 on 29/04/21.
//

import Foundation
struct ClimaDatos: Decodable {
    let name: String
    let main: Main
    let weather: [Weather]
    
}
struct Weather: Decodable {
    let description: String
    let id: Int
}

struct Main: Decodable {
    let temp: Double
    let feels_like: Double
}
