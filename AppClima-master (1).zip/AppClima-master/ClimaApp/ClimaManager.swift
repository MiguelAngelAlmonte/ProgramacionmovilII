//
//  ClimaManager.swift
//  ClimaApp
//
//  Created by Mac1 on 27/04/21.
//

import Foundation
import CoreLocation

protocol ClimaManagerDelegado {
    func actualizarClima(clima: ClimaModelo) 
    
    func huboError(erro: Error)
    
}

struct ClimaManager {
    let climaUrl = "https://api.openweathermap.org/data/2.5/weather?appid=37960f84c272b830bed31d30be18b1ba&units=metric&lang=es"
    
    var delegado: ClimaManagerDelegado?
    
    func buscarClima(ciudad: String){
        let urlString = "\(climaUrl)&q=\(ciudad)"
        realizarSolicitud(urlString: urlString)
        
    }
    
    func buscarClimaGPS(lat: CLLocationDegrees,long: CLLocationDegrees)  {
        let urlString = "\(climaUrl)&lat=\(lat)&lon=\(long)"
        realizarSolicitud(urlString: urlString)
    }
    
    func realizarSolicitud(urlString: String){
        //1.- Crear una Url
        if let url = URL(string: urlString){
            //2.- Crear una URlSession
            let session = URLSession(configuration: .default)
            //3.- Asignarle una tarea a la urlsession
            let tarea = session.dataTask(with: url) { (datos, respuesta, error) in
                if error != nil {
                    delegado?.huboError(erro: error!)
                    return
                }
                
                if let datosSeguros = datos {
                    //parsear json
                    if let objClima = self.parsearJSON(datosClima: datosSeguros){
    //                    let ClimaVC = ClimaViewController()
      //                  ClimaVC.actualizarClima(objClima: objClima)
                        self.delegado?.actualizarClima(clima: objClima)
                    }
                }
            }
            //4.- iniciar la tarea
            tarea.resume()
        }
    }
    func parsearJSON(datosClima: Data) -> ClimaModelo?{
        //crear un decodificador json
        let decodificador = JSONDecoder()
        do {
            let datosDecodificados = try
            decodificador.decode(ClimaDatos.self, from: datosClima)
            //imprimir datos de la API en formato ordenado
            print("La ciudad que buscaste es: \(datosDecodificados.name)")
            print("temperatura: \(datosDecodificados.main.temp)")
            print("id \(datosDecodificados.weather[0].id)")
            print("La sensacion termica es \(datosDecodificados.main.feels_like)")
            ///////////////////////////////////////////////////////////////////
            let sensasion = datosDecodificados.main.feels_like
            let id = datosDecodificados.weather[0].id
            let ciudad = datosDecodificados.name
            let temp = datosDecodificados.main.temp
            
            let objClimma = ClimaModelo(temp: temp, nombreCiudad: ciudad, id: id, sensacion: sensasion)
            print(objClimma.sensacionString)
            print(objClimma.condicionClima)
            print(objClimma.tempString)
            return objClimma
            
        } catch  {
            delegado?.huboError(erro: error)
            return nil
        }
    }
    
    
   
    
}
