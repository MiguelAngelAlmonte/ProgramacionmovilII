//
//  ViewController.swift
//  ClimaApp
//
//  Created by marco rodriguez on 01/04/21.
//

import UIKit
import CoreLocation

class ClimaViewController: UIViewController, UITextFieldDelegate, ClimaManagerDelegado,CLLocationManagerDelegate {
    
    func huboError(erro: Error) {
        print(erro.localizedDescription)
        
        DispatchQueue.main.async {
            let alerta = UIAlertController(title: "ERROR", message: "Lugar no encontrada", preferredStyle: .actionSheet)
            let accionOK = UIAlertAction(title: "Aceptar", style: .default, handler: nil)
            alerta.addAction(accionOK)
            self.present(alerta, animated: true, completion: nil)
        }
    }
    
    
    var latitud: CLLocationDegrees?
    var longitud: CLLocationDegrees?
    
    var climaManager = ClimaManager()
    //obtener cordenadas de la ubicacion del usuario
    var climaLocationManager = CLLocationManager()

    @IBOutlet weak var buscarTextField: UITextField!
    @IBOutlet weak var condicionClimaImageView: UIImageView!
    @IBOutlet weak var temperaturaLabel: UILabel!
    @IBOutlet weak var sensacionterLabel: UILabel!
    @IBOutlet weak var ciudadLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        //Establecer esta clase como el delegado del ClimaManager
        climaLocationManager.delegate = self
        climaLocationManager.requestLocation()
        climaLocationManager.requestWhenInUseAuthorization()
        
        climaManager.delegado = self
             
        buscarTextField.delegate = self
    }

    @IBAction func buscarButton(_ sender: UIButton) {
        buscarTextField.endEditing(true)
      //  print(buscarTextField.text!)
       // ciudadLabel.text = buscarTextField.text
       // buscarTextField.text = ""
    }
    @IBAction func GPSButton(_ sender: UIButton) {
        climaManager.buscarClimaGPS(lat: latitud ?? 0, long: longitud ?? 0)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        buscarTextField.endEditing(true)
       // ciudadLabel.text = buscarTextField.text
       // print(buscarTextField.text!)
        buscarTextField.text = ""
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if buscarTextField.text != "" {
            return true
        } else {
            buscarTextField.placeholder = "Escribe algo..."
            return false
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        climaManager.buscarClima(ciudad: buscarTextField.text!)
        //ciudadLabel.text = buscarTextField.text
        //buscarTextField.text = ""
    }
    
    func actualizarClima(clima: ClimaModelo) {
        DispatchQueue.main.async {
            self.temperaturaLabel.text = clima.tempString
            self.ciudadLabel.text = clima.nombreCiudad
            self.condicionClimaImageView.image = UIImage(systemName: clima.condicionClima)
            self.sensacionterLabel.text = clima.sensacionString
        }
        
       // print(clima.tempString)
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let ubicacion = locations.last{
            let latitud = ubicacion.coordinate.latitude
            let longitud = ubicacion.coordinate.longitude
            self.latitud = latitud
            self.longitud = longitud
            print("Se obtubo \(latitud) & longitud \(longitud)")
            climaManager.buscarClimaGPS(lat: latitud, long: longitud)
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error al obtener la ubicacion")
    }
    
}
    
