//
//  ViewController.swift
//  notes
//
//  Created by Mac1 on 17/04/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    let defaultsDB = UserDefaults.standard
    
    var notaEditar : String?
    
    var pocision: Int?
    
    var fechas = [" "]
    
    var notas=["Ir al super","Estudiar","Dormir"]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tablaNotas.dequeueReusableCell(withIdentifier: "cell" , for: indexPath)
        celda.textLabel?.text = notas[indexPath.row]
        celda.detailTextLabel?.text = fechas[indexPath.row]
        return celda
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(notas[indexPath.row])
        pocision = indexPath.row
        notaEditar = notas[indexPath.row]
        performSegue(withIdentifier: "editar", sender: self) 
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "editar"{
            let objEditar = segue.destination as! EditarViewController
            objEditar.recibirNota = notaEditar
            objEditar.notas = notas
            objEditar.recibirposicion = pocision
        }
    }
    
    func tableView(_ tableView: UITableView,commit editingStyle:UITableViewCell.EditingStyle,forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            notas.remove(at: indexPath.row)
            tablaNotas.reloadData()
            
            self.defaultsDB.setValue(self.notas, forKey: "notas")
           tablaNotas.reloadData()
        }
    }

    @IBOutlet weak var tablaNotas: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tablaNotas.delegate = self
        tablaNotas.dataSource = self
        
        if let arregloNotas = defaultsDB.array(forKey: "notas") as? [String]{
            notas = arregloNotas
        }else{
            notas=[""]
        }
        if let arreglofechas = defaultsDB.array(forKey: "fechas") as? [String]{
            fechas = arreglofechas
        }else {
            fechas=[""]
        }
        //notas = defaultsDB.array(forKey: "notas") as! [String]
        print(defaultsDB.array(forKey: "notas"))
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let arregloNotas = defaultsDB.array(forKey: "notas") as? [String]{
            notas = arregloNotas
        }
        tablaNotas.reloadData()
        
    }

    @IBAction func addNotaButton(_ sender: UIBarButtonItem) {
        var textField = UITextField()
        
        let alerta = UIAlertController(title: "Agregar nuevo", message: "Nueva nota", preferredStyle: .alert)
        let accion = UIAlertAction(title: "Aceptar", style: .default){ _ in
            print("Nota agregada")
            print(textField.text)
            let fechaformat = DateFormatter()
            let fecanew = Date()
            fechaformat.dateStyle = .short
            let fecha = fechaformat.string(from: fecanew)
            self.fechas.append("\(fecha)")
            self.notas.append(textField.text ?? "vacio")
            print(self.notas)
            self.defaultsDB.setValue(self.notas, forKey: "notas")
            self.defaultsDB.setValue(self.fechas, forKey: "fechas")
            
            
            self.tablaNotas.reloadData()
        }
        let accionCancelar = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        alerta.addAction(accion)
        alerta.addAction(accionCancelar)
        
        alerta.addTextField { (textFieldAlerta) in
            textFieldAlerta.placeholder = "Agregar nueva nota..."
            textField = textFieldAlerta
        }
        
        
        present(alerta, animated: true, completion: nil)
        
    }
    
}

