//
//  EditarViewController.swift
//  notes
//
//  Created by Mac1 on 18/04/21.
//

import UIKit

class EditarViewController: UIViewController {
    let defaultsDB = UserDefaults.standard
    var recibirposicion: Int?
    var recibirNota: String?
    var notas: [String]?
    @IBOutlet weak var editarNotaTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        editarNotaTextField.text = recibirNota
        print(defaultsDB.array(forKey: "notas") as? [String])
        
        print(notas)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func guardarButton(_ sender: UIButton) {
        notas?.remove(at: recibirposicion!)
        if let notaEditada = editarNotaTextField.text{
            notas?.append(notaEditada)
        }
        
        
        defaultsDB.setValue(notas, forKey: "notas")
        navigationController?.popToRootViewController(animated: true)
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
